<html>
    <head>
        <title>Relatórios</title>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="catalogo/visao/recursos/img/cadimaweb.ico"/>

        <!-- Início - CSS  -->
        <!-- ATENÇÃO!!!! Para importar um novo css, fazer o include dentro do arquivo "combine-minify-css.php". -->
        <!-- O único include de css que deve existir nessa página é o "combine-minify-css.php". -->
        <link rel="stylesheet" href="http://localhost/catalogo/visao/recursos/css/combine-minify-css.php">
        <!-- Fim - CSS -->

        <!-- Início - Javascript -->
        <!-- ATENÇÃO!!!! Para importar um novo javascript, fazer o include dentro do arquivo "combine-js.php". -->
        <!-- O único include de javascript que  deve existir nessa página é o "combine-js.php". -->
        <script src="http://localhost/catalogo/visao/recursos/js/combine-js.php"></script>
        <!-- Fim - Javascript -->

    

</head>
<body style="background-color: white;">
    <div id="wrapper">

        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <ul class="nav navbar-top-links navbar-right" id="menu-atalhos">
                                    <li class="dropdown" title="Página inicial"><a href="/admin/index"><i class="glyphicon glyphicon-home"></i></a></li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="glyphicon glyphicon-user"></i> <i class="glyphicon glyphicon-triangle-bottom gi-0-8x"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li>
                                <p style="margin: 10px;text-align: center;">admin<br></p>
                            </li>
                            <li><a href="/trocar-senha"><i class="glyphicon glyphicon-lock"></i> Trocar senha de acesso</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="/logout"><i class="glyphicon glyphicon-log-in"></i> Sair</a>
                            </li>
                        </ul>
                    </li>
                            </ul>
            <!-- (IF LOGADO) -->
                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a href="http://localhost/catalogo/administracao_geral.php" class="active"><i class="glyphicon glyphicon-home"></i> Início</a>
                            </li>
                            <li>
                                <a href="http://localhost/catalogo/om.php"><i class="glyphicon glyphicon-menu-hamburger"></i> OM</a>
                            </li>
                            <li>
                                <a href="/admin/contratacoesdiretas"><i class="glyphicon glyphicon-menu-hamburger"></i> Administrador</a>
                            </li>
                            <li>
                                <a href="/admin/atas"><i class="glyphicon glyphicon-menu-hamburger"></i> Elemento Organizacional</a>
                            </li>
                            <li>
                                <a href="/admin/contratos"><i class="glyphicon glyphicon-menu-hamburger"></i> Função</a>
                            </li>
                                                            <li>
                                    <a href="/admin/organizacoesmilitares"><i class="glyphicon glyphicon-menu-hamburger"></i> Telefone</a>
                                </li>
                                <li>
                                    <a href="/admin/fornecedores"><i class="glyphicon glyphicon-menu-hamburger"></i> Pessoa</a>
                                </li>
                                <li>
                                    <a href="/admin/usuarios"><i class="glyphicon glyphicon-menu-hamburger"></i> Relatórios</a>
                                </li>
                                <li>
                                    <a href="/admin/usuarios"><i class="glyphicon glyphicon-menu-hamburger"></i> Ajuda</a>
                                </li>
                                                    </ul>
                    </div>
                </div>
            <!-- (/IF LOGADO) -->
        </nav>
        <div id="page-wrapper" style="height: 100%;">
            <div class="row" style="padding: 0px 0px 0px 0px;">
                <div class="col-sm-12">
                    <div style="float: left; margin-top: 10px; visibility: 
    hidden
;"><a href="#" onclick="window.history.back();"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;&nbsp;Voltar</a></div>
                    <h3 class="page-header">Relatórios</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div style="background-color: #efefef; margin: -20px 0px 15px 0px; padding: 7px 7px 7px 7px; font-size: small; width: 100%" class="col-sm-12">
                        
    <a href="/admin/index"><span class="glyphicon glyphicon-home"></span></a>&nbsp;&nbsp;
    
                    </div>
                </div>
            </div>
            <div>
        <div class="alert invisivel" id="mensagem">  
            <a class="close" id="fechar">×</a>
            <div id="mensagem-conteudo"> x </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <form action="/admin/licitacoes" method="GET" id="formFiltroLicitacoes" name="formFiltroLicitacoes">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label for="ano" class="nowrap">Ano</label> 
                                        <input type="text" class="form-control" id="ano" name="ano" value="" required="required">
                                    </div>
                                </div>
                                <div class="col-sm-10">
                                                                            <div class="form-group">
                                            <label for="om">OM</label>
                                            <input type="text" class="form-control autocomplete" id="om" name="om" maxlength="20" autocomplete=off value="">
                                        </div>
                                                                    </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-2">
                                    <div class="form-group" style="margin-bottom: 0">
                                        <br/>
                                        <input type="submit" class="btn btn-primary btn-md" value="Pesquisar" id="btnPesquisa" name="btnPesquisa"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
                    <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            &nbsp;
                            <a href="/admin/licitacao" class="btn btn-primary btn-sm float-right" data-toggle="Adicionar" data-placement="bottom" title="Adicionar">
                                <span class="glyphicon glyphicon-plus"  aria-hidden="true" style="color:#FFFFFF;" ></span>
                            </a>
                        </div>

                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover display" id="tabela-licitacoes">
                                <thead>
                                    <tr>
                                        <th style="vertical-align: middle;" rowspan="2">Ano</th>
                                        <th style="vertical-align: middle;" rowspan="2">Número</th>
                                        <th style="vertical-align: middle;" rowspan="2">OM</th>
                                        <th style="vertical-align: middle;" rowspan="2">Objeto</th>
                                        <th colspan="2" class="text-center no-sort th-opcoes-top-header">Opções</th>
                                    </tr>
                                    <tr>
                                        <th class="no-sort text-center border-right-none th-opcoes-modificar">Modificar</th>
                                        <th class="no-sort text-center th-opcoes-remover" >Remover</th>
                                    </tr>
                                </thead>
                                <tbody>
                                                                            <tr class="odd gradeX" id='3' data-href-click="/admin/licitacao/3">
                                            <td class="cursor">
                                                2020
                                            </td>
                                            <td class="cursor">
                                                10
                                            </td>
                                            <td class="cursor">
                                                DAdM
                                            </td>
                                            <td class="cursor">
                                                100
                                            </td>
                                            <td class="text-center border-right-none">
                                                <a href="/admin/licitacao/3">
                                                    <button type="button" class="btn btn-default btn-borda" data-toggle="Modificar" data-placement="bottom" title="Modificar">
                                                        <span class="glyphicon glyphicon-pencil"  style="color:#2E6DA4;" aria-hidden="true"></span>
                                                    </button>
                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <a href="javascript:void(0);" onclick="$.deleteTabela('/admin/licitacao/3', '2020.'-'.10', '3', 'tabela-licitacoes','a Licitação ');
                                                        return false;">
                                                    <button class="btn btn-default btn-borda" data-toggle="Remover" data-placement="bottom" title="Remover">
                                                        <span class="glyphicon glyphicon-trash"  aria-hidden="true" style="color:#2E6DA4;" ></span>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
            </div>

        </div>

</div>
            
</div>



</body>
</html>