 /* 
 * jQuery-MB
 * Funções customizadas para uso interno dos sistemas na DAdM.
 */

$(document).ready(function() {
    $('form').each(function(){
        if($(this).attr('data-ajax-method') === 'POST') {
            geraId($(this));
            $(this).attr ('onsubmit', "return $.postForm('"+$(this).attr('id')+"');");
        } else if ($(this).attr('data-ajax-method') === 'PUT') {
            geraId($(this));
            $(this).attr ('onsubmit', "return $.putForm('"+$(this).attr('id')+"');");
        }
    });
});

function geraId(form) {
    if(!form.attr('id')){
        form.attr('id','form'+ Math.floor(Math.random() * 65536));
    }
}

$.postForm = function(formId) {
    var form = $('#' + formId);
    $. ajax ({
        url: form.attr('action'),
        type: form.attr('data-ajax-method'),
        data: form.serialize(),
        success: function() {
            alert('Inserido com sucesso!');
            window.location.href = form.attr('action');
        }
    });
    return false;
};

$.putForm = function(formId) {
    var form = $('#' + formId);
    $. ajax ({
        url: form.attr('action'),
        type: form.attr('data-ajax-method'),
        data: JSON. stringify (form.serializeArray()),
        success: function() {
            alert('Modificado com sucesso!');
            window.location.href = form.attr('action');
        }
    });
    return false;
};

$.deleteForm = function (url) {
    return $. ajax (
        {
          url: url,
          type: 'DELETE',
          success: function() {
            alert('Removido com sucesso!');
            location.reload();
          }
        }
    );
};
