/* 
 * jQuery-MB
 * Funções customizadas para uso interno dos sistemas na DAdM.
 */
$(document).ready(function () {

    $(".mascaraCep").mask("99999-999");
    $(".mascaraNumericoDoisDigitos").mask("99");
    $(".mascaraNumericoSeteDigitos").mask("9999999");
    $(".mascaradata").mask("99/99/9999");
    $('.mascaraNumeroComDecimal').mask("000.000.000,00", {reverse: true});
    $(".mascaraNIP").mask("99.9999.99");
    $(".mascaraTelefone").mask("(99)9999-9999");
    $(".mascaraCPF").mask("999.999.999.99");
    $(".mascaraCNPJ").mask("99.999.999/9999-99");
    
    $(".mascaraNumeroProcesso").mask("999.999/9999-9");
    

    $('[data-toggle="tooltip"]').tooltip();

    //visualizar linha ao clicar
    $('body').on('click', '.cursor', function () {
        var tr = $(this).parent();
        $(location).attr('href', tr.attr("data-href-click"));
    });

    
    $('form').each(function () {
        if ($(this).attr('data-ajax-method') === 'POST') {
            geraId($(this));
            $(this).attr('onsubmit', "return $.postForm('" + $(this).attr('id') + "');");
        } else if ($(this).attr('data-ajax-method') === 'PUT') {
            geraId($(this));
            $(this).attr('onsubmit', "return $.putForm('" + $(this).attr('id') + "');");
        }
    });

    $("#fechar").click(function () {
        $("#mensagem").addClass("invisivel");
    });
    
        //autocomplete
    $("input.autocomplete").autocomplete({
        source: function (request, response) {

            var url = "/organizacoes-militares-por-sigla/" + request.term;
            $.get(url, function (data) {
                response($.parseJSON(data));
            });
        },
        minLength: 2
    });
    
    $("input.autocomplete").blur(function () {
        var input = $(this);
        var sigla = input.val().split(' ')[0];
        var url = "/valida-organizacoes-militares-por-sigla/" + sigla;

        $.get(url, function (data) {
            if (data == "") {
                input.val("");
            } else {
                input.val($.parseJSON(data));
            }
        });
    });


    $('.arquivoUpload').fileupload({
        url: '/arquivo/upload',
        dataType: 'json',
        start: function (e, data) {

            var fileUploadBlock = $(this).closest(".file-upload-block");
            fileUploadBlock.find('#progress').show();
        },
        done: function (e, data) {
            $.each(data.result.files, function (index, file) {
                var form = $('#' + e.target.form.id);
                var fileUploadBlock = form.find(".file-upload-block");
                var files = fileUploadBlock.find('#files');
                files.empty();

                var div = $('<div class="file-item" />');
                div.append($('<p/>').text(file.nomeOriginalArquivo));
                div.append($('<input type="hidden" id="nomeArquivo" name="nomeArquivo" value="' + file.nomeArquivo + '">'));
                div.append($('<input type="hidden" id="nomeOriginalArquivo" name="nomeOriginalArquivo" value="' + file.nomeOriginalArquivo + '">'));

                files.append(div);
            });
        },
        error: function (e, data) {
            exibirErro(e.responseText);
            $('#progress').hide();
            $('#files').empty();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress .progress-bar').css(
                    'width',
                    progress + '%'
                    );
        }
    }).prop('disabled', !$.support.fileInput)
            .parent().addClass($.support.fileInput ? undefined : 'disabled');


    $('.arquivoUploadMultiple').fileupload({
        url: '/arquivo/upload',
        dataType: 'json',
        start: function (e, data) {
            var fileUploadBlock = $(this).closest(".file-upload-block");
            fileUploadBlock.find('#progress').show();
        },
        done: function (e, data) {
            $.each(data.result.files, function (index, file) {
                var form = $('#' + e.target.form.id);
                var fileUploadBlock = form.find(".file-upload-block");
                var files = fileUploadBlock.find('.files');

                fileUploadBlock.find('#progress').hide();

                // files.empty();

                //Adiciona valores

                var tr = $('<tr class="odd gradeX file-item" data-nome-original-arquivo="' + file.nomeOriginalArquivo + '" />');

                tr.append('<td class="cursor">' +
                        '<span> ' + file.nomeOriginalArquivo + '</span>' +
                        '<input type="hidden" name="nomeArquivoTemp[]" value="' + file.nomeArquivo + '\" id="nomeArquivoTemp">' +
                        '<input type="hidden" name="nomeOriginalArquivoTemp[]" value="' + file.nomeOriginalArquivo + '\" id="nomeOriginalArquivoTemp"></td>');

                tr.append('<td class="cursor"></td>');
                tr.append('<td class="cursor"><a class="excluir-item" href="javascript:void(0);"><span class="glyphicon glyphicon glyphicon-remove glyphiconicon-danger" aria-hidden="true"></span></a></td>');

                fileUploadBlock.find('.table').append(tr);
             //   $("#tabela-files tbody").append(tr);
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress .progress-bar').css(
                    'width',
                    progress + '%'
                    );
        }
    }).prop('disabled', !$.support.fileInput)
            .parent().addClass($.support.fileInput ? undefined : 'disabled');


    $(".files").on("click", ".excluir-item", function () {
        var fileItem = $(this).closest('.file-item');
        var nomeOriginalArquivo = fileItem.data("nome-original-arquivo");

        var texto = "Deseja mesmo excluir o arquivo " + nomeOriginalArquivo + "   ?";

        var name = bootbox.confirm({
            message: texto,
            buttons: {
                confirm: {
                    label: 'Sim',
                    className: 'btn-success'
                },
                cancel: {
                    label: 'Não',
                    className: 'btn-danger float-right margin-left-10px'
                }
            },
            callback: function (result) {
                if (result) {
                    fileItem.remove();
                }
            }
        });

    });
    
    
    
});


function geraId(form) {
    if (!form.attr('id')) {
        form.attr('id', 'form' + Math.floor(Math.random() * 65536));
    }
}

$.postForm = function (formId) {
    var form = $('#' + formId);
    var formValues = serializeArrayAndUnMask(formId);

    //console.log(formValues.length);

    var inputFile = form.find("input[type=file]");
    console.dir(inputFile);
    $.each(inputFile, function (index, inputFileItem) {

        if (inputFileItem.files && inputFileItem.files.length == 1) {
            var formData = new FormData();
            var file = inputFileItem.files[0]
            formData.set("file", file, file.name);
            //console.log(inputFileItem.attr("data-url"));
            //console.dir(inputFileItem.data("url"));
            if ($(inputFileItem).attr("data-url")) {
                var dataUrl = $(inputFileItem).attr("data-url");
            } else {
                var dataUrl = "/arquivo/upload";
            }
            $.ajax({
                url: dataUrl,
                type: "POST",
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                async: false,
                success: function (data)
                {
                    //console.log(data);
                    formValues.push({name: "caminho", value: 'visao/recursos/fileupload/'});
                    formValues.push({name: "nomeOriginal", value: file.name});
                    //console.dir(formValues);
                }
            });

        }

    });

    //console.log(formValues.length);

    $.ajax({
        url: form.attr('action'),
        type: 'POST',
        data: formValues,
        success: function (data, textStatus, request) {
            //pega id do formulario
            var id_form = form.attr('id');

            /*
             if (callbacksuccess) {
             setTimeout(function () {
             callbacksuccess();
             }, 100);
             }
             */

            if (request.getResponseHeader('redirectTo')) {
                window.location.href = request.getResponseHeader('redirectTo');
            } else {
                form.trigger("reset");
                form.find(".file-upload-block").find("#progress").hide();
                form.find(".file-upload-block").find("#files").empty();
                exibirSucesso(data);
                toTop();
            }

        },
        error: function (data) {
            exibirErro(data.responseText);
            toTop();
        }
    });
    return false;
};

$.putForm = function (formId) {
    var form = $('#' + formId);
    var formValues = serializeArrayAndUnMask(formId);

    $.ajax({
        url: form.attr('action'),
        type: 'PUT',
        data: JSON.stringify(formValues),
        success: function (data, textStatus, request) {
 
            if (request.getResponseHeader('redirectTo')) {
                window.location.href = request.getResponseHeader('redirectTo');
            } else {
                exibirSucesso(data);
                toTop();
            }
            //alert('Modificado com sucesso!');

        },
        error: function (data) {
            exibirErro(data.responseText);
            toTop();
        }
    });
    return false;
};

function serializeArrayAndUnMask(formId) {
    var form = $('#' + formId);
    formValues = form.serializeArray();

    //Remove as máscaras globais

    formValues.forEach(function (valor, index) {

        var existeColchete = valor.name.indexOf("[]") > -1;
        if (!existeColchete) {

            var elemento = form.find('#' + valor.name);

            if (elemento.hasClass('mascaraNumeroComDecimal')) {
                valor.value = valor.value.replace(/[.]/g, '').replace(/[,]/g, '.');
            } else if (elemento.hasClass('mascaraNIP')) {
                valor.value = valor.value.replace(/[.]/g, '');
            } else if (elemento.hasClass('mascaraCep')) {
                valor.value = elemento.cleanVal();
            } else if (elemento.hasClass('mascaraTelefone')) {
                valor.value = elemento.cleanVal();
            } else if (elemento.hasClass('mascaraCPF')) {
                valor.value = elemento.cleanVal();
            } else if (elemento.hasClass('mascaraNumeroProcesso')) {
                valor.value = elemento.cleanVal();
            } else if (elemento.hasClass('mascaraCNPJ')) {
                valor.value = elemento.cleanVal();
            }
        }

    });

    //Remove as máscaras específicas do projeto caso método exista
    if (typeof removeMascarasEspecificas === "function") {
        formValues = removeMascarasEspecificas(formId, formValues);
    }

    return formValues;
}

$.deleteForm = function (url, nome, id, form, item, callbacksuccess) {
    var nome_red = "<span style='color:#ff0000;font-weight: bold;border-bottom: 1px dotted #ff0000'>" + nome + "</span>";

    var texto = "Deseja mesmo excluir " + item + nome_red + "   ?";

    var name = bootbox.confirm({
        message: texto,
        buttons: {
            confirm: {
                label: 'Sim',
                className: 'btn-success'
            },
            cancel: {
                label: 'Não',
                className: 'btn-danger float-right margin-left-10px'
            }
        },
        callback: function (result) {
            if (result) {
                return $.ajax({
                    url: url,
                    type: 'DELETE',
                    success: function (data) {

                        exibirSucesso(data);
                        toTop();

                        $('#' + form + ' input').each(function () {
                            $(this).val('');
                            $(this).attr("checked", false);
                        });

                        $("option:selected").removeAttr("selected");

                        $('#' + form).css("display", "none");
                        $('.page-header').css("display", "none");
                        $('h4').css("display", "none");
                        
                        if (callbacksuccess) {
                            callbacksuccess();
                        }
                    },
                    error: function (data) {
                        exibirErro(data.responseText);
                        toTop();
                    }
                });
            }
        }
    });
};

$.deleteTabela = function (url, nome, id, tabela, item, callbacksuccess) {
    var nome_red = "<span style='color:#ff0000;font-weight: bold;border-bottom: 1px dotted #ff0000'>" + nome + "</span>";

    var texto = "Deseja mesmo excluir " + item + nome_red + "   ?";

    var item_tabela = $("#" + tabela + " #" + id);


    var name = bootbox.confirm({
        message: texto,
        buttons: {
            confirm: {
                label: 'Sim',
                className: 'btn-success'
            },
            cancel: {
                label: 'Não',
                className: 'btn-danger float-right margin-left-10px'
            }
        },
        callback: function (result) {
            if (result) {
                return $.ajax({
                    url: url,
                    type: 'DELETE',
                    success: function (data) {
                        item_tabela.addClass("efeitoExcluir");

                        setTimeout(function () {
                            item_tabela.remove();
                            exibirSucesso(data);
                            toTop();
                        }, 500);

                        $('#' + tabela + ' input').each(function () {
                            $(this).val('');
                        });

                        if (callbacksuccess) {
                            callbacksuccess();
                        }
                    },
                    error: function (data) {
                        exibirErro(data.responseText);
                    }
                });
            }
        }
    });
};


$.desbloquearUsuario = function (formId, idUsuario, nomeCompleto, login) {

    var form = $('#' + formId);
    var formValues = serializeArrayAndUnMask(formId);

    var texto = "Deseja realmente desbloquear o usuario " + login + " - " + nomeCompleto + "?";

    var name = bootbox.confirm({
        message: texto,
        buttons: {
            confirm: {
                label: 'Sim',
                className: 'btn-success margin-left-10px'
            },
            cancel: {
                label: 'Não',
                className: 'btn-danger float-right margin-left-10px'
            }
        },
        callback: function (result) {
            if (result) {
                return $.ajax({
                    url: '/desbloquear-usuario/' + idUsuario,
                    type: 'PUT',
                    data: JSON.stringify(formValues),
                    success: function (data, textStatus, request) {
                        if (request.getResponseHeader('redirectTo')) {
                            window.location.href = request.getResponseHeader('redirectTo');
                        } else {
                            form.trigger("reset");
                            exibirSucesso(data);
                            toTop();
                        }

                    },
                    error: function (data) {
                        exibirErro(data.responseText);
                    }
                });
            }
        }
    });
};


function ApagaMensagem() {
    var mensagem = $("#mensagem");
    var x = setTimeout(function () {
        mensagem.addClass("efeitoExcluir");
        setTimeout(function () {
            mensagem.addClass("invisivel");
        }, 500);
    }, 10000);
}

function exibirSucesso(texto) {
    $("#mensagem-conteudo").empty();
    $("#mensagem-conteudo").append($.parseHTML(texto));
    $("#mensagem").removeClass("invisivel");
    $("#mensagem").removeClass("efeitoExcluir");
    $("#mensagem").removeClass("alert-danger");
    $("#mensagem").addClass("alert-success");
    ApagaMensagem();
}

function exibirErro(texto) {
    $("#mensagem-conteudo").empty();
    $("#mensagem-conteudo").append($.parseHTML(texto));
    $("#mensagem").removeClass("invisivel");
    $("#mensagem").removeClass("efeitoExcluir");
    $("#mensagem").removeClass("alert-success");
    $("#mensagem").addClass("alert-danger");
    ApagaMensagem();
}

function recarregaPaginaAoVoltar() {
    window.addEventListener("pageshow", function (event) {
        var historyTraversal = event.persisted ||
                (typeof window.performance != "undefined" &&
                        window.performance.navigation.type === 2);
        if (historyTraversal) {
            // Handle page restore.
            window.location.reload();
        }
    });
}

//colorir os botões de acordo com o clique (escritura, processo, ...)
function activeButton(button) {
    $(".list-group-item").removeClass("active");
    $("#" + button).addClass("active");
}

function toTop() {
    $('html, body').animate({
        scrollTop: 0
    }, 1000, 'linear');
}

function formataNumeroDecimal(num) {
  return (
    num
      .toFixed(2) // always two decimal digits
      .replace('.', ',') // replace decimal point character with ,
      .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.') 
  ); // use . as a separator
}

function removeMascarasEspecificas(formId, formValues) {
    var form = $('#' + formId);

    //Remove as máscaras padrões
    formValues.forEach(function (valor, index) {
        var existeColchete = valor.name.indexOf("[]") > -1;
        if (!existeColchete) {

            var elemento = form.find('#' + valor.name);

            if (elemento.hasClass('mascaraRip')) {
                valor.value = elemento.cleanVal();
            }
        }
    });

    return formValues;
}