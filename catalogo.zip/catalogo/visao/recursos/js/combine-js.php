<?php // compress and merge CSS files
header('Content-type: application/javascript');
//ob_start("compress");

//function compress($buffer) {
//	$buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
//	$buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
//	return $buffer;
//}

include('jquery.min.js');
include('bootstrap.min.js');
include('metisMenu.min.js');
include('jquery.dataTables.min.js');
include('dataTables.bootstrap.min.js');
include('dataTables.responsive.js');
include('sb-admin-2.min.js');
include('apexcharts.js');
include('jquery.mask.js');
include('jquery-ui.min.js');
include('jquery.fileupload.js');
include('graficos-mb-1.0.0.js');
include('licitacoescontratos.js');
include('checkListGroup.js');
include('bootbox.min.js');
include('leaflet-src.js');
include('mapa-mb-1.0.0.js');

ob_end_flush();
?>