function criarMapaLeaflet(mapa) {
    $('#mapiderror').hide();
    
    var leaflet = Lea.noConflict();
    var mymap = leaflet.map(mapa).setView([-11.4902481, -50.440224], 4.4);

    var normal = leaflet.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        maxZoom: 18,
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
                '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1
    });

    var satelite = leaflet.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18,
        attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
        tileSize: 512,
        zoomOffset: -1
    }).addTo(mymap);


    var layers = {
        "Normal": normal,
        "Satélite": satelite
    };

    var tombos = leaflet.layerGroup();
    tombos.addTo(mymap);

    var overlays = {
        "Tombos": tombos
    };



    leaflet.control.layers(layers, overlays).addTo(mymap);
    $.get("/tombos/geolocalizacao/", function (data) {
        var geojsonFeature = JSON.parse(data);
        leaflet.geoJSON(geojsonFeature, {
            onEachFeature: onEachFeature
        }).addTo(tombos);
    });


    satelite.on('tileerror', function (error, tile) {
       // mymap.removeLayer(tombos);
       // mymap.remove();
        $('#mapid').hide();
        $('#mapiderror').show();
    });

    /* Lea.TileLayer.include({
     _tileOnError: function (done, tile, e) {
     alert('deu ruim no mapa')
     //   map.removeLayer(tile);
     }
     });*/

    function onEachFeature(feature, layer) {
        layer.on('click', function (e) {
            console.log(e);
            window.location = feature.properties.url;
        });

        layer.on('mouseover', function (e) {
            console.log(e);
            layer.bindPopup(feature.properties.codigo + ' - ' + feature.properties.Descricao).openPopup();
        });
    }
}

function criarMapaLeafletOld(mapa) {
    var leaflet = Lea.noConflict();

    var normal = leaflet.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        maxZoom: 18,
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
                '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1
    });

    var satelite = leaflet.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18,
        attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
        tileSize: 512,
        zoomOffset: -1
    });

    var mymap = leaflet.map('mapid', {laryers: [normal, satelite]}).setView([-11.4902481, -50.440224], 4.4);

    var layers = {
        "Normal": normal,
        "Satélite": satelite
    };

    var tombos = leaflet.layerGroup();

    var overlays = {
        "Tombos": tombos
    };

    leaflet.control.layers(layers, overlays).addTo(mymap);

    $.get("/tombos/geolocalizacao/", function (data) {
        var geojsonFeature = JSON.parse(data);
        leaflet.geoJSON(geojsonFeature, {
            onEachFeature: onEachFeature
        }).addTo(tombos);
    });

    function onEachFeature(feature, layer) {
        layer.on('click', function (e) {
            window.location = feature.properties.url;
        });
        layer.on('mouseover', function (e) {
            layer.bindPopup(feature.properties.codigo + ' - ' + feature.properties.Descricao).openPopup();
        });
    }

}
