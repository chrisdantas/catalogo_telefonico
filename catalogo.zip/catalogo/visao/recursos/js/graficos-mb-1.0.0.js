var coresGraficos = ['#3B3EAC', '#DC3912', '#FF9900', '#006400', '#990099', '#8B4513', '#0099C6', '#DD4477', '#66AA00', '#B82E2E',
    '#316395', '#994499', '#22AA99', '#AAAA11', '#6633CC', '#E67300', '#5574A6', '#329262', '#3366CC', '#3B3EAC', '#109618']

function criarGraficoBarras(grafico, tituloGrafico, eixoX, eixoY, numeroDecimal = false) {
    var options = {
        series: [{
                data: eixoY,
                name: []
            }],
        title: {
            text: tituloGrafico,
            floating: true,
            position: 'top',
            offsetY: -5,
            align: 'center',
            style: {
                color: '#304758'
            }
        },
        chart: {
            height: 350,
            type: 'bar',
            events: {
                click: function (chart, w, e) {
                    // console.log(chart, w, e)
                }
            }
        },
        colors: coresGraficos,
        plotOptions: {
            bar: {
                columnWidth: '75%',
                distributed: true,
                dataLabels: {
                    position: 'top', // top, center, bottom
                }
            }
        },

        dataLabels: {
            enabled: true,
            formatter: function (val) {
                if (val > 0) {
                    if (numeroDecimal)
                        return formataNumeroDecimal(val);
                    else
                        return val;
                }
                //  return val + "%";
            },
            offsetY: -20,
            style: {
                fontSize: '12px',
                colors: ["#304758"]
            }
        },

        legend: {
            show: false
        },
        xaxis: {
            categories: eixoX,
            labels: {
                style: {
                    // colors: coresGraficos,
                    fontSize: '12px'
                }
            },
            tooltip: {
                enabled: true,
                offsetY: -35,
            }
        },
    };
    var chart = new ApexCharts(grafico, options);
    chart.render();
}

function criarGraficoBarrasHorizontal(grafico, tituloGrafico, eixoX, eixoY, numeroDecimal = false) {
    var options = {
        series: [{
                data: eixoY,
                name: []
            }],
        title: {
            text: tituloGrafico,
            floating: true,
            position: 'top',
            offsetY: -5,
            align: 'center',
            style: {
                color: '#304758'
            }
        },
        chart: {
            height: 350,
            type: 'bar',
            events: {
                click: function (chart, w, e) {
                    // console.log(chart, w, e)
                }
            }
        },
        colors: coresGraficos,
        plotOptions: {
            bar: {
                columnWidth: '75%',
                distributed: true,
                horizontal : true,
                dataLabels: {
                    position: 'top', // top, center, bottom
                }
            }
        },

        dataLabels: {
            enabled: false,
            formatter: function (val) {
                if (val > 0) {
                    if (numeroDecimal)
                        return formataNumeroDecimal(val);
                    else
                        return val;
                }
                //  return val + "%";
            },
            offsetY: -20,
            style: {
                fontSize: '12px',
                colors: ["#304758"]
            }
        },

        legend: {
            show: false
        },
        xaxis: {
            categories: eixoX,
            labels: {
                style: {
                    // colors: coresGraficos,
                    fontSize: '12px'
                }
            },
            tooltip: {
                enabled: true,
                offsetY: -35,
            }
        },
    };
    var chart = new ApexCharts(grafico, options);
    chart.render();
}


function criarGraficoPizza(grafico, tituloGrafico, legenda, valores) {
    var options = {
        series: valores,
        title: {
            text: tituloGrafico,
            floating: false,
            position: 'top',
            offsetY: -5,
            align: 'center',
            style: {
                color: '#304758'
            }
        },
        chart: {
            width: 450,
            type: 'pie',
            toolbar: {
                show: true
            }
        },
        colors: coresGraficos,
        labels: legenda,
        responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
    };

    var chart = new ApexCharts(grafico, options);
    chart.render();
}

function criarObjetoGraficoBarrasMultiColunas(array, titulo) {
    var objEixoY = new Object();
    objEixoY['data'] = array;
    objEixoY['titulo'] = titulo;

    return objEixoY;
}

function criarGraficoBarrasMultiColunas(grafico, tituloGrafico, eixoX, eixoY) {
    var options = {
        series: [{
                data: []
            }],
        title: {
            text: tituloGrafico,
            floating: true,
            position: 'top',
            offsetY: -5,
            align: 'center',
            style: {
                color: '#304758'
            }
        },
        chart: {
            type: 'bar',
            height: 350
        },
        colors: coresGraficos,

        plotOptions: {
            bar: {
                columnWidth: '55%',
                dataLabels: {
                    position: 'top', // top, center, bottom
                }
            }
        },
        dataLabels: {
            enabled: true,
            formatter: function (val) {
                if (val > 0) //Exibe datalabel apenas se o valor for maior que 0
                    return val;
            },
            offsetY: -20,
            style: {
                fontSize: '12px',
                colors: ["#304758"]
            }
        },
        stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
        },
        xaxis: {
            categories: eixoX,
        },
        fill: {
            opacity: 1
        }
    };

    var chart = new ApexCharts(grafico, options);
    chart.opts.series.pop();

    for (var i = 0; i < eixoY.length; i++) {
        chart.opts.series.push({
            name: eixoY[i].titulo,
            data: eixoY[i].data,
        });
    }
    chart.render();
}

function criarGraficoSimpleDunut(grafico, tituloGrafico, legenda, valores) {
    var options = {
        series: valores,
        chart: {
            type: 'donut',
            width: 460,
            toolbar: {
                show: true
            }
        },
        title: {
            text: tituloGrafico,
            floating: true,
            position: 'top',
            offsetY: -5,
            align: 'center',
            style: {
                color: '#304758'
            }
        },
        colors: coresGraficos,
        labels: legenda,
        responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
    };

    var chart = new ApexCharts(grafico, options);


    chart.render();
}

function criarGraficoStackedBars(grafico, tituloGrafico, eixoX, eixoY) {
    var options = {
        series: [{
                data: []
            }],
        chart: {
            type: 'bar',
            stacked: true,
            //stackType: '100%'
        },
        plotOptions: {
            bar: {
                horizontal: true,
                height: 400
            },
        },
        stroke: {
            width: 1,
            colors: ['#fff']
        },
        title: {
            text: tituloGrafico,
            floating: true,
            position: 'top',
            offsetY: -5,
            align: 'center',
            style: {
                color: '#304758'
            }
        },
        xaxis: {
            categories: eixoY,
        },
        tooltip: {
            y: {
                formatter: function (val) {
                    return val;
                }
            }
        },
        fill: {
            opacity: 1

        },
        dataLabels: {
            enabled: false
        },
        colors: coresGraficos,
        legend: {
            position: 'top',
            horizontalAlign: 'center',
            offsetY: 20
        }
    };

    var chart = new ApexCharts(grafico, options);

    chart.opts.series.pop();

    for (var i = 0; i < eixoX.length; i++) {
        chart.opts.series.push({
            name: eixoX[i].titulo,
            data: eixoX[i].data,
        });


    }

    chart.render();
}
/*
 function criarGraficoBarrasCarregamentoDinamico(graficoPricipal, graficoDetalhado, tituloGrafico,legendaGraficoPrincipal) {
 var options = {
 series: [{
 name: 'PRODUCT A',
 data: [44, 55, 41, 67, 22, 43]
 }],
 title: {
 text: tituloGrafico,
 floating: true,
 position: 'top',
 offsetY: -5,
 align: 'center',
 style: {
 color: '#304758'
 }
 },
 subtitle: {
 text: '(Clique nas colunas para obter mais detalhes)',
 offsetX: 15
 },
 chart: {
 id: 'barYear',
 height: 400,
 width: '100%',
 type: 'bar',
 events: {
 dataPointSelection: function (e, chart, opts) {
 var graficoDetalhadoEl = graficoDetalhado;
 var graficoPrincipalEl = graficoPricipal;
 
 if (opts.selectedDataPoints[0].length === 1) {
 if (graficoDetalhadoEl.classList.contains("active")) {
 updateQuarterChart(chart, 'barQuarter')
 } else {
 graficoPrincipalEl.classList.add("chart-quarter-activated")
 graficoDetalhadoEl.classList.add("active");
 updateQuarterChart(chart, 'barQuarter')
 }
 } else {
 updateQuarterChart(chart, 'barQuarter')
 }
 
 if (opts.selectedDataPoints[0].length === 0) {
 graficoPrincipalEl.classList.remove("chart-quarter-activated")
 graficoDetalhadoEl.classList.remove("active");
 }
 
 },
 updated: function (chart) {
 updateQuarterChart(chart, 'barQuarter')
 }
 }
 },
 plotOptions: {
 bar: {
 distributed: true,
 horizontal: true,
 barHeight: '75%',
 dataLabels: {
 position: 'bottom'
 }
 }
 },
 dataLabels: {
 enabled: true,
 textAnchor: 'start',
 style: {
 colors: ['#fff']
 },
 formatter: function (val, opt) {
 return opt.w.globals.labels[opt.dataPointIndex]
 },
 offsetX: 0,
 dropShadow: {
 enabled: true
 }
 },
 
 colors: coresGraficos,
 
 states: {
 normal: {
 filter: {
 type: 'desaturate'
 }
 },
 active: {
 allowMultipleDataPointsSelection: true,
 filter: {
 type: 'darken',
 value: 1
 }
 }
 },
 tooltip: {
 x: {
 show: false
 },
 y: {
 title: {
 formatter: function (val, opts) {
 return opts.w.globals.labels[opts.dataPointIndex]
 }
 }
 }
 },
 xaxis: {
 categories: legendaGraficoPrincipal,
 },
 yaxis: {
 labels: {
 show: false
 }
 }
 };
 
 var chart = new ApexCharts(graficoPricipal, options);
 chart.render();
 
 var optionsQuarter = {
 series: [{
 data: []
 }],
 chart: {
 id: 'barQuarter',
 height: 400,
 width: '100%',
 type: 'bar',
 stacked: true
 },
 plotOptions: {
 bar: {
 columnWidth: '50%',
 horizontal: false
 }
 },
 legend: {
 show: false
 },
 grid: {
 yaxis: {
 lines: {
 show: false,
 }
 },
 xaxis: {
 lines: {
 show: true,
 }
 }
 },
 yaxis: {
 labels: {
 show: false
 }
 },
 title: {
 text: 'Quarterly Results',
 offsetX: 10
 },
 tooltip: {
 x: {
 formatter: function (val, opts) {
 return opts.w.globals.seriesNames[opts.seriesIndex]
 }
 },
 y: {
 title: {
 formatter: function (val, opts) {
 return opts.w.globals.labels[opts.dataPointIndex]
 }
 }
 }
 }
 };
 
 var chartQuarter = new ApexCharts(graficoDetalhado, optionsQuarter);
 chartQuarter.render();
 
 chart.addEventListener('dataPointSelection', function (e, chart, opts) {
 var quarterChartEl = document.querySelector("#chart-quarter");
 var yearChartEl = document.querySelector("#chart-year");
 
 if (opts.selectedDataPoints[0].length === 1) {
 if (quarterChartEl.classList.contains("active")) {
 updateQuarterChart(chart, 'barQuarter')
 } else {
 yearChartEl.classList.add("chart-quarter-activated")
 quarterChartEl.classList.add("active");
 updateQuarterChart(chart, 'barQuarter')
 }
 } else {
 updateQuarterChart(chart, 'barQuarter')
 }
 
 if (opts.selectedDataPoints[0].length === 0) {
 yearChartEl.classList.remove("chart-quarter-activated")
 quarterChartEl.classList.remove("active");
 }
 
 })
 
 chart.addEventListener('updated', function (chart) {
 updateQuarterChart(chart, 'barQuarter')
 })
 
 document.querySelector("#model").addEventListener("change", function (e) {
 chart.updateSeries([{
 // data: makeData()
 }])
 })
 }*/
