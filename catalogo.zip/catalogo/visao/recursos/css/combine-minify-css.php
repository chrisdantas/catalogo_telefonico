<?php // compress and merge CSS files
header('Content-type: text/css');
ob_start("compress");

function compress($buffer) {
	$buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
	$buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
	return $buffer;
}

include('bootstrap.min.css');
include('metisMenu.min.css');
include('dataTables.bootstrap.css');
include('dataTables.responsive.css');
include('sb-admin-2.min.css');
include('font-awesome.min.css'); //Analisar se realmente é necessário, atualmente só é utilizado para as setinhas do datatable.
include('jquery-ui.min.css');
include('jquery.fileupload.css');
include('apexcharts.css');
include('cadima.css');
include('chart.min.css');
include('leaflet.css');

ob_end_flush();
?>