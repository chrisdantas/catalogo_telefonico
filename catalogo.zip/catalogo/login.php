<html>
    <head>
        <title>Login</title>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="catalogo/visao/recursos/img/cadimaweb.ico"/>

        <!--google fonts - Kulim Park - Semi-bold 600-->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Kulim+Park:wght@600&display=swap" rel="stylesheet">

        <link href="css/style.css" rel="stylesheet"/>

        <!-- Início - CSS  -->
        <!-- ATENÇÃO!!!! Para importar um novo css, fazer o include dentro do arquivo "combine-minify-css.php". -->
        <!-- O único include de css que deve existir nessa página é o "combine-minify-css.php". -->
        <link rel="stylesheet" href="http://localhost/catalogo/visao/recursos/css/combine-minify-css.php">
        <!-- Fim - CSS -->

        <!-- Início - Javascript -->
        <!-- ATENÇÃO!!!! Para importar um novo javascript, fazer o include dentro do arquivo "combine-js.php". -->
        <!-- O único include de javascript que  deve existir nessa página é o "combine-js.php". -->
        <script src="http://localhost/catalogo/visao/recursos/js/combine-js.php"></script>
        <!-- Fim - Javascript -->

    
    </head>
<body style="background-color: white; height: 100%;">
<div id="page" class="container">
        <div class="row">
            <img src="imagens/logotipo.png" style="display: block;margin: 0 auto;margin-top:1%;min-width:150px;max-width:200px;">
            <br><br><br>
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading" style="text-align:center;">
                        <h3 class="panel-title">Login</h3>
                    </div>
                    <div class="panel-body">
                        <form method="post" action="http://sisdiv.dadm.mb/login/entrar">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="NIP" name="nip" type="text" maxlength="8" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Senha" name="senha" type="password" value="" required>
                                </div>
                                    <div class="row" style="font-size: smaller">
                                        <div class="col-md-1">
                                            <span class="glyphicon glyphicon-ok"></span>
                                        </div>
                                        <div class="col-md-10">
                                            Seu <i>login</i> será lembrado desde que não haja 30 minuto(s) de inatividade no sistema.
                                        </div>
                                    </div><br>
                                <input class="btn btn-primary btn-block" type="submit" value="Entrar" />
                                
                            </fieldset>
                        </form>
                    </div>
                </div>
                            </div>
        </div>
    </div>

</body>
</html>
