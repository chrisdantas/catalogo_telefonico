<html>
    <head>
        <title>Administração</title>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="catalogo/visao/recursos/img/cadimaweb.ico"/>

        <!-- Início - CSS  -->
        <!-- ATENÇÃO!!!! Para importar um novo css, fazer o include dentro do arquivo "combine-minify-css.php". -->
        <!-- O único include de css que deve existir nessa página é o "combine-minify-css.php". -->
        <link rel="stylesheet" href="http://localhost/catalogo/visao/recursos/css/combine-minify-css.php">
        <!-- Fim - CSS -->

        <!-- Início - Javascript -->
        <!-- ATENÇÃO!!!! Para importar um novo javascript, fazer o include dentro do arquivo "combine-js.php". -->
        <!-- O único include de javascript que  deve existir nessa página é o "combine-js.php". -->
        <script src="http://localhost/catalogo/visao/recursos/js/combine-js.php"></script>
        <!-- Fim - Javascript -->

    

</head>
<body style="background-color: white;">
    <div id="wrapper">

        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <ul class="nav navbar-top-links navbar-right" id="menu-atalhos">
                                    <li class="dropdown" title="Página inicial"><a href="/admin/index"><i class="glyphicon glyphicon-home"></i></a></li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="glyphicon glyphicon-user"></i> <i class="glyphicon glyphicon-triangle-bottom gi-0-8x"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li>
                                <p style="margin: 10px;text-align: center;">admin<br></p>
                            </li>
                            <li><a href="/trocar-senha"><i class="glyphicon glyphicon-lock"></i> Trocar senha de acesso</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="/logout"><i class="glyphicon glyphicon-log-in"></i> Sair</a>
                            </li>
                        </ul>
                    </li>
                            </ul>
            <!-- (IF LOGADO) -->
                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a href="http://localhost/catalogo/administracao_geral.php" class="active"><i class="glyphicon glyphicon-home"></i> Início</a>
                            </li>
                            <li>
                                <a href="http://localhost/catalogo/om.php"><i class="glyphicon glyphicon-menu-hamburger"></i> OM</a>
                            </li>
                            <li>
                                <a href="/admin/contratacoesdiretas"><i class="glyphicon glyphicon-menu-hamburger"></i> Administrador</a>
                            </li>
                            <li>
                                <a href="/admin/atas"><i class="glyphicon glyphicon-menu-hamburger"></i> Elemento Organizacional</a>
                            </li>
                            <li>
                                <a href="/admin/contratos"><i class="glyphicon glyphicon-menu-hamburger"></i> Função</a>
                            </li>
                                                            <li>
                                    <a href="/admin/organizacoesmilitares"><i class="glyphicon glyphicon-menu-hamburger"></i> Telefone</a>
                                </li>
                                <li>
                                    <a href="/admin/fornecedores"><i class="glyphicon glyphicon-menu-hamburger"></i> Pessoa</a>
                                </li>
                                <li>
                                    <a href="/admin/usuarios"><i class="glyphicon glyphicon-menu-hamburger"></i> Relatórios</a>
                                </li>
                                <li>
                                    <a href="/admin/usuarios"><i class="glyphicon glyphicon-menu-hamburger"></i> Ajuda</a>
                                </li>
                                                    </ul>
                    </div>
                </div>
            <!-- (/IF LOGADO) -->
        </nav>
        <div id="page-wrapper" style="height: 100%;">
            <div class="row" style="padding: 0px 0px 0px 0px;">
                <div class="col-sm-12">
                    <div style="float: left; margin-top: 10px; visibility: 
    hidden
;"><a href="#" onclick="window.history.back();"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;&nbsp;Voltar</a></div>
                    <h3 class="page-header">Catálogo Telefônico</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div style="background-color: #efefef; margin: -20px 0px 15px 0px; padding: 7px 7px 7px 7px; font-size: small; width: 100%" class="col-sm-12">
                        
    <a href="/admin/index"><span class="glyphicon glyphicon-home"></span></a>&nbsp;&nbsp;
    
                    </div>
                </div>
            </div>
            
</div>
</body>
</html>

